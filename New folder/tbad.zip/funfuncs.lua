

function DrawLove()
-- Drawing Love L
RemoveBlock( 3,10 )
RemoveBlock( 3,11 )
RemoveBlock( 3,12 )
RemoveBlock( 3,13 )
RemoveBlock( 3,14 )
RemoveBlock( 3,15 )
RemoveBlock( 4,15 )
RemoveBlock( 5,15 )
RemoveBlock( 6,15 )

-- Drawing Love O
RemoveBlock( 8,8 )
RemoveBlock( 11,8 )
RemoveBlock( 8,10 )
RemoveBlock( 9,10 )
RemoveBlock( 10,10 )
RemoveBlock( 8,11 )
RemoveBlock( 8,12 )
RemoveBlock( 8,13 )
RemoveBlock( 8,14 )
RemoveBlock( 8,15 )
RemoveBlock( 9,15 )
RemoveBlock( 10,15 )
RemoveBlock( 11,10 )
RemoveBlock( 11,11 )
RemoveBlock( 11,12 )
RemoveBlock( 11,13 )
RemoveBlock( 11,14 )
RemoveBlock( 11,15 )

-- Drawing Love V
RemoveBlock( 13,10 )
end